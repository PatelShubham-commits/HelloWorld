package com.newgen.demo;



import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
 

 
public class UserDAO {
 
    public void addUserDetails(String iduser, String username, String pass) {
        try {
            //configuring hibernate
            Configuration configuration = new Configuration().configure();
 
            //create sessionfactory
            SessionFactory sessionFactory = configuration.buildSessionFactory();
 
            //Get Session object
            Session session = sessionFactory.openSession();
 
            //Starting Transaction
            Transaction transaction = session.beginTransaction();
            User user = new User();
            user.setIduser(iduser);
            user.setUsername(username);
            user.setPass(pass);
           
            session.save(user);
            transaction.commit();
            System.out.println("\n\n Details Added \n");
 
        } catch (HibernateException e) {
            System.out.println(e.getMessage());
            System.out.println("error");
        }
 
    }
 
}