package com.newgen.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewgenDemoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
